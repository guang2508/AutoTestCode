# -*- coding: utf-8 -*-
#   __author__:lenovo
#   2019/12/2


a = input()
b = input()
c = input()
d = input()


print("a =", a)
print("b =", b)
print("c =", c)
print("d =", d)
