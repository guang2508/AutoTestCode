# -*- coding: utf-8 -*-
#   __author__:lenovo
#   2019/12/2

import os

# ret = os.system("for %i in (1,2,10) do  @echo %i")
ret = os.system("dt")

print("ret =", ret)
