# -*- coding: utf-8 -*-
#   __author__:lenovo
#   2019/12/2

import subprocess



# ret = subprocess.check_output(["ping", "www.baidu.com"])
#
# print(ret.decode("gbk"))


subprocess.Popen("ipconfig")
print("after")
